using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Node2
{
    public Vector3 worldPosition;//where is our node in the world

    public Node2(Vector3 _worldPos)
    {
        worldPosition = _worldPos;
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Grid2 : MonoBehaviour
{
    public Vector2 gridWorldSize;//how big is grid
    public float nodeRadius;//how big each node will be
    Node2[,] grid;
    public GameObject character;
    public int enlargenGrid;

    float nodeDiameter;
    int gridSizeX;
    int gridSizeY;

    public float maxMapHeight;

    void Start()
    {
        nodeDiameter = nodeRadius * 2;
        CreateGrid();
    }

    void FixedUpdate()
    {

        
    }

    public void CreateGrid()
    {
        //calculate grid x and y(z)
        float x = Mathf.Abs(transform.position.x - character.transform.position.x) + enlargenGrid;//size of x needs to be the difference plus some space
        float z = Mathf.Abs(transform.position.z - character.transform.position.z) + enlargenGrid;//same goes for our z
        gridWorldSize = new Vector2(x, z);//z is the "y" if we look top down

        gridSizeX = Mathf.RoundToInt(gridWorldSize.x / nodeDiameter);//how many nodes in x
        gridSizeY = Mathf.RoundToInt(gridWorldSize.y / nodeDiameter);//same for y

        //start making grid (this is where Lague starts this method)
        grid = new Node2[gridSizeX, gridSizeY];
        Vector3 middle = (transform.position + character.transform.position) / 2;
        Vector3 bottomLeft = middle - Vector3.right * gridWorldSize.x / 2 - Vector3.forward * gridWorldSize.y / 2;//get bottom left corner

        //everything is walkable, but this is a good way to get all of the height data
        for (int xInt = 0; xInt < gridSizeX; xInt++)
        {
            for (int y = 0; y < gridSizeY; y++)
            {
                Vector3 rayStartLocation = bottomLeft + Vector3.right * (xInt * nodeDiameter + nodeRadius) + Vector3.forward * (y * nodeDiameter + nodeRadius) + Vector3.up * maxMapHeight;

                //ray down
                Ray ray = new Ray(rayStartLocation, Vector3.down);//ray goes from enemy to character
                RaycastHit hit;

                if (Physics.Raycast(ray, out hit, maxMapHeight + 10))//go a little farther down just to ensure we are good
                {//if get a hit
                    //Debug.Log(hit.point);
                    if (hit.transform.gameObject.layer == LayerMask.NameToLayer("Character"))//if we hitting character then move it down the player size
                    {
                        rayStartLocation = hit.point;
                        Vector3 hitWithoutCharHeight = rayStartLocation - Vector3.up * character.transform.localScale.y;//y height dif
                        Debug.Log(hitWithoutCharHeight);
                        grid[xInt, y] = new Node2(hitWithoutCharHeight);
                    }
                    else
                    {
                        grid[xInt, y] = new Node2(hit.point);
                    }

                }
            }
        }


    }

    //returns where character is
    public Node2 NodeFromWorldPoint(Vector3 worldPosition)
    {
        Vector3 worldPosWithAdjustmentToGrid = worldPosition - ((transform.position + worldPosition) / 2);//get position in relation to the grid (this makes it as if we are at 000)
        //find x and y for grid
        float percentX = Mathf.Clamp01((worldPosWithAdjustmentToGrid.x + gridWorldSize.x / 2) / gridWorldSize.x);//need to do position - distance from center of grid
        float percentY = Mathf.Clamp01((worldPosWithAdjustmentToGrid.z + gridWorldSize.y / 2) / gridWorldSize.y);

        int x = Mathf.RoundToInt((gridSizeX-1) * percentX);
        int y = Mathf.RoundToInt((gridSizeY - 1) * percentX);

        Debug.Log(worldPosWithAdjustmentToGrid);

        return grid[x, y];
    }

    void OnDrawGizmos()
    {
        Gizmos.DrawWireCube((transform.position + character.transform.position) / 2, new Vector3(gridWorldSize.x, 1, gridWorldSize.y));//center is between character and enemy
        if (grid != null)
        {
            Node2 playerNode = NodeFromWorldPoint(character.transform.position);
            Gizmos.color = Color.white;
            foreach (Node2 n in grid)
            {
                Gizmos.color = Color.white;
                if (playerNode == n)
                {
                    Gizmos.color = Color.cyan;
                }
                Gizmos.DrawCube(n.worldPosition, Vector3.one * (nodeDiameter - 0.1f));

                //Debug.DrawRay(n.worldPosition + (Vector3.up * maxMapHeight), Vector3.down * (maxMapHeight + 10));
            }
        }
    }
}
